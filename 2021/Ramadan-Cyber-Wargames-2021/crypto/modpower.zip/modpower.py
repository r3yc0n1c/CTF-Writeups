import random
import os


def encrypt(m,par1,par2,l):
 for i in range(0,l):
  cipher.append((ord(m[i])^(par1[i]^par2[i])))
 return cipher



par1 = list()
par2 = list()

for i in range(25,1000):
   par1.append((random.getrandbits(32)))
   par2.append(pow(x,i,p))


leaked = par1[0:624]
print("leaked=",leaked)
par1 = par1[::-1]
cipher = list()

m = "CTFAE{}"
cipher = encrypt(m,par1,par2,len(m))
print("cipher=",cipher)


