import random
from Crypto.Util.number import bytes_to_long, long_to_bytes, inverse


def getkey():
    a = random.getrandbits(128)
    b = random.getrandbits(128)
    c = random.getrandbits(128)
    d = random.getrandbits(128)
    e = a * b - 1
    f = c * e + a
    g = d * e + b;
    h = c * d * e + a * d + c * b + 1;
    pub = [h, f]
    priv = g
    key = [pub, priv]
    return key


def encrypt(plaintext, pub):
    return (plaintext * pub[1]) % pub[0]


flag = b''
p = bytes_to_long(flag)
key = getkey()
c = encrypt(p, key[0])
print("ct= ", c)
print("h= ", key[0][0])
print("f= ", key[0][1])




